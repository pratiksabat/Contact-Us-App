package com.pratik.contact_us_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
